<?php
define('DB_PATH', dirname(__FILE__) . '/../database/banco_de_dados.sqlite');
?>
