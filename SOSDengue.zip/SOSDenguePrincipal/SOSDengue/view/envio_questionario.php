<?php
require_once '../model/conexao_banco_dados.php';

$db = new Database();
$conn = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo '<pre>';
    print_r($_POST);
    echo '</pre>';
    
    if (isset($_POST['questionario']) && is_array($_POST['questionario'])) {
        $questionario = $_POST['questionario'];
        $sql = "INSERT INTO questionarios (respostas) VALUES (:respostas)";
        $params = [':respostas' => json_encode($questionario)];
        $db->query($sql, $params);

        header("Location: agradecimento.php");
        exit();
    } else {
        echo 'Erro: Nenhum questionário foi enviado.';
    }
} else {
    echo 'Erro: Requisição inválida.';
}
?>
