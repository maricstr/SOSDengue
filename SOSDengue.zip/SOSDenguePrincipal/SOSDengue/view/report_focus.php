<!DOCTYPE html>
<html>
<head>
    <title>Denunciar Foco de Dengue</title>
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        /* Estilo para o cabeçalho */
        h1 {
            color: #4CAF50;
            font-size: 2em;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Estilo para o formulário */
        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        /* Estilo para os labels e inputs */
        label {
            display: block;
            margin: 10px 0;
            font-size: 1em;
            color: #555;
        }

        input[type="text"],
        textarea {
            width: calc(100% - 20px);
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        input[type="file"] {
            margin-top: 5px;
        }

        /* Estilo para o botão de submit */
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>

</head>
<body>
    <h1>Registro de Foco de Dengue</h1>
    <form action="submit_report.php" method="post" enctype="multipart/form-data">
        <label>
            Endereço da ocorrência:
            <input type="text" name="address" required>
        </label><br>
        <label>
            Descrição da ocorrência:
            <textarea name="description" required></textarea>
        </label><br>
        <label>
            Imagem:
            <input type="file" name="image">
        </label><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>
