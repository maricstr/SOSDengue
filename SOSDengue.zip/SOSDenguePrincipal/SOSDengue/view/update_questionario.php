// controller/update_questionario.php
<?php
require_once '../model/conexao_banco_dados.php';

$db = new Database();
$conn = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $respostas = $_POST['respostas'];
    $sql = "UPDATE questionarios SET respostas = :respostas WHERE id = :id";
    $params = [':respostas' => json_encode($respostas), ':id' => $id];
    $db->query($sql, $params);

    header("Location: ../view/agradecimento.php");
    exit();
}
?>
