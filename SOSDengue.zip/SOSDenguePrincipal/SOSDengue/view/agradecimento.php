<!DOCTYPE html>
<html>
<head>
    <title>Obrigado!</title>
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 90vh;
            color: #333;
            text-align: center;
        }

        /* Estilo para o cabeçalho */
        h1 {
            color: #4CAF50;
            font-size: 2em;
            margin-bottom: 20px;
        }

        /* Estilo para o parágrafo */
        p {
            font-size: 1.2em;
            margin: 0 20px;
        }
    </style>
</head>
<body>
    <h1>Agradecemos a sua denúncia!</h1>
    <p>Sua contribuição é muito importante para o combate à dengue.</p>
</body>
</html>
