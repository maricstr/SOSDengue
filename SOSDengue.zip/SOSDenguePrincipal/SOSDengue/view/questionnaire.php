<!DOCTYPE html>
<html>
<head>
    <title>Análise de Sintomas</title>
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            margin: 40px;
            padding: 30px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        /* Estilo para o cabeçalho */
        h1 {
            color: #4CAF50;
            font-size: 2em;
            text-align: center;
            margin-bottom: 50px;
        }

        /* Estilo para o formulário */
        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        /* Estilo para os labels e inputs */
        label {
            display: block;
            margin: 10px 0;
            font-size: 1em;
            color: #555;
        }

        input[type="checkbox"] {
            margin-right: 10px;
        }

        /* Estilo para o botão de submit */
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #58c6e7;
        }
    </style>
</head>
<body>
    <h1>Assinale todos os seus sintomas nos últimos 3 dias:</h1>
    <form action="envio_questionario.php" method="post">
        <label>
            <input type="checkbox" name="questionario[]" value="Dores no corpo e cabeça"> Dores no corpo e cabeça
        </label><br>
        <label>
            <input type="checkbox" name="questionario[]" value="Febre alta (acima de 38,5°C)"> Febre alta (acima de 38,5°C)
        </label><br>
        <label>
            <input type="checkbox" name="questionario[]" value="Manchas pelo corpo"> Manchas pelo corpo
        </label><br>
        <label>
            <input type="checkbox" name="questionario[]" value="Náusea e/ou vômitos"> Náusea e/ou vômitos
        </label><br>
        <label>
            <input type="checkbox" name="questionario[]" value="Mal-estar"> Mal-estar
        </label><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>
