<?php
require_once '../model/conexao_banco_dados.php';

$db = new Database();
$conn = $db->connect();

// Verifica se a tabela 'reports' existe, e cria se não existir
$sqlCreateTable = "CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL,
    description TEXT NOT NULL,
    image TEXT
)";
$conn->exec($sqlCreateTable);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['address'], $_POST['description'])) {
        $address = $_POST['address'];
        $description = $_POST['description'];
        $image = $_FILES['image']['name'] ?? null;

        // Move a imagem para o diretório de destino
        if ($image) {
            $targetDir = '../uploads/';
            $targetFilePath = $targetDir . basename($image);
            move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath);
        }

        $sql = "INSERT INTO reports (address, description, image) VALUES (:address, :description, :image)";
        $params = [
            ':address' => $address,
            ':description' => $description,
            ':image' => $image
        ];
        $db->query($sql, $params);

        header("Location: report_focus.php");
        exit();
    } else {
        echo 'Erro: Todos os campos obrigatórios devem ser preenchidos.';
    }
} else {
    echo 'Erro: Requisição inválida.';
}
?>
