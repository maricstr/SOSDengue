// controller/delete_questionario.php
<?php
require_once '../model/conexao_banco_dados.php';

$db = new Database();
$conn = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $sql = "DELETE FROM questionarios WHERE id = :id";
    $params = [':id' => $id];
    $db->query($sql, $params);

    header("Location: ../view/agradecimento.php");
    exit();
}
?>
