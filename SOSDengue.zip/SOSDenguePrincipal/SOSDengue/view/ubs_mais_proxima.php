<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db.php';

if (isset($_GET['questionnaire_id'])) {
    $questionnaire_id = $_GET['questionnaire_id'];

    $stmt = $pdo->prepare("SELECT * FROM questionnaire WHERE id = :questionnaire_id");
    $stmt->bindParam(':questionnaire_id', $questionnaire_id);
    $stmt->execute();
    $questionnaire = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($questionnaire) {
        // Aqui você pode processar os dados do questionário e exibir a unidade de saúde mais próxima
        echo "<h1>Unidade Básica de Saúde mais Próxima</h1>";
        echo "<p>Você será encaminhado para a unidade de saúde mais próxima com base nos seguintes sintomas:</p>";
        echo "<ul>";
        echo "<li>Sintoma 1: " . ($questionnaire['question1'] ? 'Sim' : 'Não') . "</li>";
        echo "<li>Sintoma 2: " . ($questionnaire['question2'] ? 'Sim' : 'Não') . "</li>";
        echo "<li>Sintoma 3: " . ($questionnaire['question3'] ? 'Sim' : 'Não') . "</li>";
        echo "<li>Sintoma 4: " . ($questionnaire['question4'] ? 'Sim' : 'Não') . "</li>";
        echo "<li>Sintoma 5: " . ($questionnaire['question5'] ? 'Sim' : 'Não') . "</li>";
        echo "</ul>";
        echo "<p>Por favor, dirija-se à unidade de saúde mais próxima para uma avaliação completa.</p>";
    } else {
        echo "<p>Questionário não encontrado.</p>";
    }
} else {
    echo "<p>ID do questionário não fornecido.</p>";
}
?>
