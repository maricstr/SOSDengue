<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'conexao_banco_dados.php';

try {
    $pdo = new PDO('sqlite:../database/banco_de_dados.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Criação da tabela questionario
    $sql = "CREATE TABLE IF NOT EXISTS questionario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        sintomas TEXT NOT NULL
    )";
    $pdo->exec($sql);

    // Outras criações de tabelas se necessário
} catch (PDOException $e) {
    die("Erro ao conectar ou criar tabela no banco de dados: " . $e->getMessage());
}
?>
