<?php
class Database {
    private $pdo;

    public function connect() {
        try {
            $this->pdo = new PDO('sqlite:' . __DIR__ . '/database.db');
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Criar a tabela questionarios se ela não existir
            $this->pdo->exec("CREATE TABLE IF NOT EXISTS questionarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                respostas TEXT NOT NULL
            )");
            
            return $this->pdo;
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
            exit;
        }
    }

    public function query($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            echo 'Query failed: ' . $e->getMessage();
            exit;
        }
    }
}
?>
