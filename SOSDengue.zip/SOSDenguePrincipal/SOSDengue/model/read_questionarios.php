// model/read_questionarios.php
<?php
require_once 'conexao_banco_dados.php';

$db = new Database();
$conn = $db->connect();

$sql = "SELECT * FROM questionarios";
$result = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);
?>
