o projeto não possui APIs utilizadas. 

link GIT: https://github.com/maricstr/SOSDengue.git